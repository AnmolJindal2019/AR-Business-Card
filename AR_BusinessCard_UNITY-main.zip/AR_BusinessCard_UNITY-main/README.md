# AR_BusinessCard_UNITY

![ezgif com-gif-maker](https://user-images.githubusercontent.com/75037497/121231063-92a33900-c8ad-11eb-83f2-14af2a422bae.gif)
---

<h4 align="left">This is an Augmented Reality business/visiting card made with the help of Unity Engine and Vuforia engine. Just Install the apk on your android mobile and scan the image provided to see the resuts.</h4>


⭐️ From [AnmolJindal2019](https://github.com/AnmolJindal2019)
